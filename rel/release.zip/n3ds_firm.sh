#!/bin/bash
wget http://nus.cdn.c.shop.nintendowifi.net/ccs/download/0004013820000002/00000021 -O ./skeith/lib/firmware/native
wget http://nus.cdn.c.shop.nintendowifi.net/ccs/download/0004013820000002/cetk     -O ./skeith/share/keys/native.cetk
wget http://nus.cdn.c.shop.nintendowifi.net/ccs/download/0004013820000102/00000000 -O ./skeith/lib/firmware/twl
wget http://nus.cdn.c.shop.nintendowifi.net/ccs/download/0004013820000102/cetk     -O ./skeith/share/keys/twl.cetk
wget http://nus.cdn.c.shop.nintendowifi.net/ccs/download/0004013820000202/00000000 -O ./skeith/lib/firmware/agb
wget http://nus.cdn.c.shop.nintendowifi.net/ccs/download/0004013820000202/cetk     -O ./skeith/share/keys/agb.cetk
