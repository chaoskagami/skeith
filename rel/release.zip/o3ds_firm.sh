#!/bin/bash
wget http://nus.cdn.c.shop.nintendowifi.net/ccs/download/0004013800000002/00000052 -O ./skeith/lib/firmware/native
wget http://nus.cdn.c.shop.nintendowifi.net/ccs/download/0004013800000002/cetk     -O ./skeith/share/keys/native.cetk
wget http://nus.cdn.c.shop.nintendowifi.net/ccs/download/0004013800000102/00000016 -O ./skeith/lib/firmware/twl
wget http://nus.cdn.c.shop.nintendowifi.net/ccs/download/0004013800000102/cetk     -O ./skeith/share/keys/twl.cetk
wget http://nus.cdn.c.shop.nintendowifi.net/ccs/download/0004013800000202/0000000B -O ./skeith/lib/firmware/agb
wget http://nus.cdn.c.shop.nintendowifi.net/ccs/download/0004013800000202/cetk     -O ./skeith/share/keys/agb.cetk
